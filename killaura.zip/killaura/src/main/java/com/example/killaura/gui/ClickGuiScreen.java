package com.example.killaura.gui;

import com.example.killaura.KillAuraMod;
import com.example.killaura.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ClickGuiScreen extends Screen {
    private static final int W = 160, H = 20, GAP = 4;

    public ClickGuiScreen() {
        super(Text.literal("KillAura Client"));
    }

    private static Text label(Module m) {
        return Text.literal(m.getName() + ": " + (m.isEnabled() ? "§aON" : "§cOFF"));
    }

    @Override
    protected void init() {
        int y = 50;
        for (Module m : KillAuraMod.MODULES.getModules()) {
            ButtonWidget button = ButtonWidget.builder(label(m), b -> {
                        m.toggle();
                        b.setMessage(label(m));
                    })
                    .dimensions(width / 2 - W / 2, y, W, H)
                    .tooltip(net.minecraft.client.gui.tooltip.Tooltip.of(Text.literal(m.getDescription())))
                    .build();
            addDrawableChild(button);
            y += H + GAP;
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 25, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Right Shift: закрыть"), width / 2, height - 20, 0xAAAAAA);
    }

    @Override
    public boolean shouldPause() { return false; }
}
