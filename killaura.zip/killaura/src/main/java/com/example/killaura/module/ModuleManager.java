package com.example.killaura.module;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void init() {
        // Добавить новый модуль = одна строка здесь
        register(new KillAura(), GLFW.GLFW_KEY_R);
        register(new Sprint(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Fullbright(), GLFW.GLFW_KEY_UNKNOWN);
        register(new ESP(), GLFW.GLFW_KEY_UNKNOWN);
    }

    private void register(Module m, int defaultKey) {
        m.keyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.killaura.module." + m.getName().toLowerCase(),
                InputUtil.Type.KEYSYM, defaultKey, "category.killaura"));
        modules.add(m);
    }

    public List<Module> getModules() { return modules; }

    public void tick(MinecraftClient client) {
        for (Module m : modules) {
            while (m.keyBinding.wasPressed()) {
                m.toggle();
                if (client.player != null) {
                    client.player.sendMessage(Text.literal(
                            m.getName() + ": " + (m.isEnabled() ? "ON" : "OFF")), true);
                }
            }
            if (m.isEnabled()) m.onTick(client);
        }
    }
}
